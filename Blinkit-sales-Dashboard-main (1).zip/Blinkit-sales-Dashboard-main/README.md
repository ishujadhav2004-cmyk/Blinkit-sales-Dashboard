# Blinkit-sales-Dashboard
Blinkit-Sales-and-Delivery-Performance-Analysis-Using Power-BI  Developed a Power BI dashboard to analyze Blinkit  sales, delivery performance,- customer behavior. Tracked KPIs like revenue, delivery time, top products and customer trends. Enabled data-driven decisions to improve delivery efficiency, inventory management and customer satisfaction.
